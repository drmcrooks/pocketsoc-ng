// Deprecated include. The next CAF release won't include this header.
