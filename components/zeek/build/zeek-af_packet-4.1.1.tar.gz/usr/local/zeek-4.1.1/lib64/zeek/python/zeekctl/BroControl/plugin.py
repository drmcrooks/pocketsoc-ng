#
# Legacy BroControl Plugin API. Importing it will abort.
#

import ZeekControl.plugin
Plugin = ZeekControl.plugin.Plugin
