#
# Settings that specify the version of ZeekControl
#

VERSION = "2.3.0-5"
ZEEKBASE = "/usr/local/zeek-4.1.1"
CFGFILE = "/usr/local/zeek-4.1.1/etc/zeekctl.cfg"
ZEEKSCRIPTDIR = "/usr/local/zeek-4.1.1/share/zeek"
LIBDIR = "/usr/local/zeek-4.1.1/lib64"
LIBDIRINTERNAL = "/usr/local/zeek-4.1.1/lib64/zeek/python"
